/* 
	Name: node-lambda-aws-dms
	Description: A Collection of Functions to be used in Lambda Executions for DMS 
	Author: Mandus Momberg
*/

var AWS = require("aws-sdk");
var cfnResp = require("./cfn_response.js");

exports.createReplicationSubnetGroup = (event, context) => {

	var responseStatus = "FAILED"

	// For Delete requests, immediately send a SUCCESS response.
    if (event.RequestType == "Delete") {
        cfnResp(event, context, "SUCCESS");
        return;
    }

    var stackId = event.StackId.toString().split("/")[1];
	var dms = new AWS.DMS({region: event.ResourceProperties.Region });
	var subnetIds = event.ResourceProperties.SubnetIds.toString().split(",");
	console.log(subnetIds);
	var identifier = event.ResourceProperties.ReplicationSubnetGroupIdentifier +  "-" + stackId
	var params = {
	  ReplicationSubnetGroupDescription: event.ResourceProperties.ReplicationSubnetGroupDescription, /* required */
	  ReplicationSubnetGroupIdentifier: identifier.substring(0,55) + "Res", /* required */
	  SubnetIds: subnetIds
	};

	console.log(params);

	dms.createReplicationSubnetGroup(params, function(err, data) {
	  if (err) {
	  	console.log(err, err.stack); // an error occurred
	  	cfnResp(event, context, responseStatus, data);
	  }
	  else     {
	  	console.log(data);
	  	responseStatus = "SUCCESS";

	  	cfnResp(event, context, responseStatus, data.ReplicationSubnetGroup);

	  }           // successful response
	});
	
}

exports.createEndpoint = (event, context) => {

	var responseStatus = "FAILED"

	// For Delete requests, immediately send a SUCCESS response.
    if (event.RequestType == "Delete") {
        cfnResp(event, context, "SUCCESS");
        return;
    }

    var stackId = event.StackId.toString().split("/")[1];
	var dms = new AWS.DMS({region: event.ResourceProperties.Region });
	var identifier = event.ResourceProperties.EndpointIdentifier +  "-" + stackId;
	var params = {
	  EndpointIdentifier: identifier.substring(0,55) + "Res", /* required */
	  EndpointType: event.ResourceProperties.EndpointType, /* required */
	  EngineName: event.ResourceProperties.EngineName, /* required */
	  Password: event.ResourceProperties.Password, /* required */
	  Port: event.ResourceProperties.Port, /* required */
	  ServerName: event.ResourceProperties.ServerName, /* required */
	  Username: event.ResourceProperties.Username /* required */
	};

	console.log(params);

	dms.createEndpoint(params, function(err, data) {
	  if (err) {
	  	console.log(err, err.stack); // an error occurred
	  	cfnResp(event, context, responseStatus, data);
	  }
	  else     {
	  	console.log(data);
	  	responseStatus = "SUCCESS";

	  	cfnResp(event, context, responseStatus, data.Endpoint);

	  }           // successful response
	});
	
}

exports.createReplicationInstance = (event, context) => {

	var responseStatus = "FAILED"

	// For Delete requests, immediately send a SUCCESS response.
    if (event.RequestType == "Delete") {
        cfnResp(event, context, "SUCCESS");
        return;
    }

    console.log(event);

    var publicaccess = event.ResourceProperties.PubliclyAccessible == "false" ? false : true

    var stackId = event.StackId.toString().split("/")[1];
	var dms = new AWS.DMS({region: event.ResourceProperties.Region });
	var identifier = event.ResourceProperties.ReplicationInstanceIdentifier +  "-" + stackId;
	var params = {
	  ReplicationInstanceClass: event.ResourceProperties.ReplicationInstanceClass, /* required */
	  ReplicationInstanceIdentifier: identifier.substring(0,55) + "Res" , /* required */
	  PubliclyAccessible: publicaccess,
	  ReplicationSubnetGroupIdentifier: event.ResourceProperties.ReplicationSubnetGroupIdentifier
	};

	console.log(params);

	dms.createReplicationInstance(params, function(err, data) {
	  if (err) {
	  	console.log(err, err.stack); // an error occurred
	  	cfnResp(event, context, responseStatus, data);
	  }
	  else     {
	  	console.log(data);
	  	responseStatus = "SUCCESS";

	  	cfnResp(event, context, responseStatus, data.ReplicationInstance);

	  }           // successful response
	});
	
}


exports.createReplicationTask = (event, context) => {

	var responseStatus = "FAILED"

	// For Delete requests, immediately send a SUCCESS response.
    if (event.RequestType == "Delete") {
        cfnResp(event, context, "SUCCESS");
        return;
    }

    var stackId = event.StackId.toString().split("/")[1];
	var dms = new AWS.DMS({region: event.ResourceProperties.Region });
	var identifier = event.ResourceProperties.ReplicationTaskIdentifier +  "-" + stackId
	var params = {
	  MigrationType: event.ResourceProperties.MigrationType, /* required */
	  ReplicationInstanceArn: event.ResourceProperties.ReplicationInstanceArn, /* required */
	  ReplicationTaskIdentifier: identifier.substring(0,55) + "Res", /* required */
	  SourceEndpointArn: event.ResourceProperties.SourceEndpointArn, /* required */
	  TableMappings: event.ResourceProperties.TableMappings, /* required */
	  TargetEndpointArn: event.ResourceProperties.TargetEndpointArn /* required */
	};

	console.log(params);

	dms.createReplicationTask(params, function(err, data) {
	  if (err) {
	  	console.log(err, err.stack); // an error occurred
	  	cfnResp(event, context, responseStatus, data);
	  }
	  else     {
	  	console.log(data);
	  	responseStatus = "SUCCESS";

	  	cfnResp(event, context, responseStatus, data.ReplicationTask);

	  }           // successful response
	});
	
}

exports.replicationInstanceWatcher = (event,context,callback) => {
	var AWS = require("aws-sdk");
	console.log(event);
	var dms = new AWS.DMS({region: event.Region });

	var params = {
	  Filters: [
	    {
	      Name: 'replication-instance-arn', /* required */
	      Values: [ /* required */
	        event.ReplicationInstanceArn
	        /* more items */
	      ]
	    },
	    /* more items */
	  ]
	};
	dms.describeReplicationInstances(params, function(err, data) {
	  if (err) console.log(err, err.stack); // an error occurred
	  else    { 
	        console.log(data);
	        console.log(data.ReplicationInstances[0].ReplicationInstanceStatus)
	        if(data.ReplicationInstances[0].ReplicationInstanceStatus == 'available'){
	            console.log("Instance is Available")
	            handlerResp(event.HandlerURL, context, "SUCCESS");
	        }
	        callback(null, 'Function Done');        
	  }// successful response
	});
}


exports.taskWatcher = (event,context,callback) => {
	var AWS = require("aws-sdk");
	console.log(event);
	var dms = new AWS.DMS({region: event.Region });

	var params = {
	  Filters: [
	    {
	      Name: 'replication-task-arn', /* required */
	      Values: [ /* required */
	        event.ReplicationTaskArn
	        /* more items */
	      ]
	    },
	    /* more items */
	  ]
	};
	dms.describeReplicationTasks(params, function(err, data) {
	  if (err) console.log(err, err.stack); // an error occurred
	  else    { 
	        console.log(data);
	        console.log(data.ReplicationTasks[0].Status)
	        if(data.ReplicationTasks[0].Status == 'ready'){
	            console.log("Instance is Available")
	            handlerResp(event.HandlerURL, context, "SUCCESS");
	        }
	        callback(null, 'Function Done');        
	  }// successful response
	});
}

function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

function handlerResp(signedurl, context, responseStatus){
 
    var responseBody = JSON.stringify({
       Status : responseStatus,
       Reason : "Configuration Complete",
       UniqueId : makeid(),
       Data : "Replication Instance Available"
    });
 
    console.log("RESPONSE BODY:\n", responseBody);
 
    var https = require("https");
    var url = require("url");
 
    var parsedUrl = url.parse(signedurl);
    var options = {
        hostname: parsedUrl.hostname,
        port: 443,
        path: parsedUrl.path,
        method: "PUT",
        headers: {
            "content-type": "",
            "content-length": responseBody.length
        }
    };
 
    console.log("SENDING RESPONSE...\n");
 
    var request = https.request(options, function(response) {
        console.log("STATUS: " + response.statusCode);
        console.log("HEADERS: " + JSON.stringify(response.headers));
        // Tell AWS Lambda that the function execution is done  
        context.done();
    });
 
    request.on("error", function(error) {
        console.log("sendResponse Error:" + error);
        // Tell AWS Lambda that the function execution is done  
        context.done();
    });
  
    // write data to request body
    request.write(responseBody);
    request.end();
}

exports.startReplicationTask = (event, context) => {

	var responseStatus = "FAILED"

	// For Delete requests, immediately send a SUCCESS response.
    if (event.RequestType == "Delete") {
        cfnResp(event, context, "SUCCESS");
        return;
    }

    var stackId = event.StackId.toString().split("/")[1];
	var dms = new AWS.DMS({region: event.ResourceProperties.Region });

	var params = {
	  ReplicationTaskArn: event.ResourceProperties.ReplicationTaskArn, /* required */
	  StartReplicationTaskType: event.ResourceProperties.StartReplicationTaskType
	};

	console.log(params);

	dms.startReplicationTask(params, function(err, data) {
	  if (err) {
	  	console.log(err, err.stack); // an error occurred
	  	cfnResp(event, context, responseStatus, data);
	  }
	  else     {
	  	console.log(data);
	  	responseStatus = "SUCCESS";

	  	cfnResp(event, context, responseStatus, data.ReplicationTask);

	  }           // successful response
	});
	
}



