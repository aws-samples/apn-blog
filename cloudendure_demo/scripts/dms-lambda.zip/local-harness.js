console.log("Starting The Test Harness.")

var lambda = require("./lambda_dms.js");

var event = {
	ResourceProperties: {
		Region: "us-west-2",
		SubnetIds: "subnet-058c6962,subnet-4f4b7439",
		ReplicationSubnetGroupDescription: "Source Replication Group",
		ReplicationSubnetGroupIdentifier: "migration-demo-src-lambda" }
	}

lambda.createReplicationSubnetGroup(event,{"context":"null"})